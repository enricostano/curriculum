package eu.europa.cedefop.europass;

public interface ConversionClientToolInterface {
    
    public void initTool (String url, String xml, String locale, String outPath);

}
